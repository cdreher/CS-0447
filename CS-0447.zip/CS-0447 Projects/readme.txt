Collin Dreher

Both my _leftHandRule and _traceBack functions work great. My _backtracking has a few issues though. I think it has to do with when false is returned. 
For example, say you go into a corner, test all of the walls, this path is now not a valid path. So the function returns false, and loads everything to the stack. 
Then starts over. I believe where this is the issue. For some reason, certain points will not be seen as already hit, so a repetition of points will occur.
Testing this is as easy as tracking through using the Maze tool, I simply ran out of time.